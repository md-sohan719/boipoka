# Integration Guide - Using Prody Admin Panel in Your Projects

## 🚀 Quick Integration

### For Laravel Projects

#### Method 1: Using as Layout Template

1. **Copy files to Laravel public directory:**
```bash
# From your admin_panel folder
cp style.css /path/to/laravel/public/assets/css/
cp -r js /path/to/laravel/public/assets/
```

2. **Create a Blade layout** (`resources/views/layouts/admin.blade.php`):
```php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Admin Panel')</title>
    
    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    @stack('styles')
</head>
<body>
    <!-- Sidebar -->
    @include('layouts.partials.sidebar')

    <!-- Main Content -->
    <main class="main-content">
        @include('layouts.partials.topbar')
        
        @yield('content')
    </main>

    <!-- Chart.js (if needed) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <!-- Custom Scripts -->
    <script src="{{ asset('assets/js/main.js') }}"></script>
    <script src="{{ asset('assets/js/charts.js') }}"></script>
    
    @stack('scripts')
</body>
</html>
```

3. **Create sidebar partial** (`resources/views/layouts/partials/sidebar.blade.php`):
```php
<aside class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <span class="material-icons logo-icon">dashboard</span>
            <span class="logo-text">{{ config('app.name') }}</span>
        </div>
        <button class="sidebar-toggle">
            <span class="material-icons">menu</span>
        </button>
    </div>

    <div class="search-box">
        <span class="material-icons">search</span>
        <input type="text" placeholder="Search..." />
        <span class="shortcut">⌘F</span>
    </div>

    <nav class="sidebar-nav">
        <a href="{{ route('dashboard') }}" class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <span class="material-icons">dashboard</span>
            <span>Dashboard</span>
        </a>
        
        <a href="#" class="nav-item has-submenu {{ request()->routeIs('projects.*') ? 'active submenu-open' : '' }}">
            <span class="material-icons">folder</span>
            <span>Projects</span>
            <div class="submenu">
                <a href="{{ route('projects.index') }}" class="submenu-item {{ request()->routeIs('projects.index') ? 'active' : '' }}">
                    <span class="material-icons">list</span>
                    <span>All Projects</span>
                </a>
                <a href="{{ route('projects.create') }}" class="submenu-item {{ request()->routeIs('projects.create') ? 'active' : '' }}">
                    <span class="material-icons">add</span>
                    <span>Create New</span>
                </a>
            </div>
        </a>
        
        <!-- Add more menu items -->
    </nav>

    <div class="sidebar-footer">
        <a href="#" class="footer-item">
            <span class="material-icons">help_outline</span>
            <span>Help center</span>
        </a>
        <a href="#" class="footer-item">
            <span class="material-icons">account_circle</span>
            <span>{{ Auth::user()->name }}</span>
        </a>
    </div>
</aside>
```

4. **Create your page** (`resources/views/dashboard.blade.php`):
```php
@extends('layouts.admin')

@section('title', 'Dashboard')

@section('content')
<div class="stats-grid fade-in-up">
    <div class="stat-card-lg">
        <div class="stat-card-header">
            <span class="stat-label">Total Users</span>
            <span class="material-icons stat-icon-sm">people</span>
        </div>
        <div class="stat-card-body">
            <h2 class="stat-value-lg" data-count="{{ $totalUsers }}">0</h2>
            <span class="stat-change positive">
                <span class="material-icons">arrow_upward</span>
                12.5%
            </span>
        </div>
    </div>
    
    <!-- More stats -->
</div>
@endsection

@push('scripts')
<script>
    // Page-specific JavaScript
</script>
@endpush
```

---

### For CodeIgniter Projects

#### Setup Instructions

1. **Copy assets to CodeIgniter:**
```bash
# Copy to public folder
cp style.css /path/to/codeigniter/public/assets/css/
cp -r js /path/to/codeigniter/public/assets/js/
```

2. **Create header view** (`app/Views/templates/header.php`):
```php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Admin Panel') ?></title>
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
```

3. **Create sidebar view** (`app/Views/templates/sidebar.php`):
```php
<aside class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <span class="material-icons logo-icon">dashboard</span>
            <span class="logo-text">Admin Panel</span>
        </div>
        <button class="sidebar-toggle">
            <span class="material-icons">menu</span>
        </button>
    </div>

    <div class="search-box">
        <span class="material-icons">search</span>
        <input type="text" placeholder="Search..." />
        <span class="shortcut">⌘F</span>
    </div>

    <nav class="sidebar-nav">
        <a href="<?= base_url('dashboard') ?>" class="nav-item <?= (uri_string() == 'dashboard') ? 'active' : '' ?>">
            <span class="material-icons">dashboard</span>
            <span>Dashboard</span>
        </a>
        
        <a href="<?= base_url('projects') ?>" class="nav-item has-submenu <?= (strpos(uri_string(), 'projects') !== false) ? 'active submenu-open' : '' ?>">
            <span class="material-icons">folder</span>
            <span>Projects</span>
            <div class="submenu">
                <a href="<?= base_url('projects') ?>" class="submenu-item">
                    <span class="material-icons">list</span>
                    <span>All Projects</span>
                </a>
                <a href="<?= base_url('projects/create') ?>" class="submenu-item">
                    <span class="material-icons">add</span>
                    <span>Create New</span>
                </a>
            </div>
        </a>
        
        <!-- Add more menu items -->
    </nav>
</aside>

<main class="main-content">
```

4. **Create footer view** (`app/Views/templates/footer.php`):
```php
</main>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script src="<?= base_url('assets/js/main.js') ?>"></script>
<script src="<?= base_url('assets/js/charts.js') ?>"></script>
</body>
</html>
```

5. **Use in your controller:**
```php
<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Dashboard',
            'totalUsers' => 1250,
            'totalProjects' => 42
        ];

        echo view('templates/header', $data);
        echo view('templates/sidebar');
        echo view('dashboard', $data);
        echo view('templates/footer');
    }
}
```

---

## 🎨 Customization Guide

### Theme Colors

Edit CSS variables in `style.css`:

```css
:root {
    /* Change these to match your brand */
    --primary-color: #3b82f6;      /* Your brand color */
    --primary-hover: #2563eb;
    
    /* Or use your own colors */
    --primary-color: #your-color;
    --accent-red: #your-red;
    --accent-green: #your-green;
}
```

### Dynamic Menu from Database

**Laravel Example:**
```php
// In your controller
$menuItems = MenuItem::with('children')->where('parent_id', null)->get();

// In blade
@foreach($menuItems as $item)
    <a href="{{ $item->url }}" class="nav-item {{ $item->children->count() ? 'has-submenu' : '' }}">
        <span class="material-icons">{{ $item->icon }}</span>
        <span>{{ $item->title }}</span>
        
        @if($item->children->count())
            <div class="submenu">
                @foreach($item->children as $child)
                    <a href="{{ $child->url }}" class="submenu-item">
                        <span class="material-icons">{{ $child->icon }}</span>
                        <span>{{ $child->title }}</span>
                    </a>
                @endforeach
            </div>
        @endif
    </a>
@endforeach
```

---

## 🔍 Menu Search Features

### Now includes:
- ✅ **Real-time menu filtering** - Type to filter menu items
- ✅ **Submenu search** - Searches inside submenus too
- ✅ **Highlight matches** - Visual feedback for matches
- ✅ **Auto-expand submenus** - Shows matching submenu items
- ✅ **No results message** - Shows when nothing matches
- ✅ **Reset on clear** - Clears filters when search is empty

### How it works:
1. Type in the search box
2. Menu items filter in real-time
3. Matching items highlight with animation
4. Submenus auto-expand if child items match
5. Clear search to show all items again

---

## 📦 Features Ready for Production

### ✅ Included Features:
- Responsive sidebar
- Working search with suggestions
- Menu/submenu filtering
- Chart integration (Chart.js)
- Table sorting/filtering
- Modal system
- Notification toasts
- Dropdown menus
- Mobile-friendly
- Dark mode ready (add data-theme attribute)

### 🎯 Use Cases:
- Laravel admin panels
- CodeIgniter dashboards
- PHP custom CMSs
- E-commerce backends
- SaaS applications
- Project management tools
- CRM systems
- Analytics dashboards

---

## 💡 Pro Tips

1. **For Laravel:** Use Blade components for reusable cards/stats
2. **For CodeIgniter:** Create helpers for common UI elements
3. **Charts:** Pass data from backend as JSON to Chart.js
4. **Authentication:** Integrate with Laravel Auth or CI4 Shield
5. **Permissions:** Show/hide menu items based on user roles
6. **API:** Works great with REST APIs and AJAX calls

---

## 🚀 Performance Tips

1. **Minify CSS/JS** for production
2. **Use CDN** for Chart.js
3. **Lazy load** charts on scroll
4. **Cache** menu items
5. **Optimize** images and icons

---

## 📝 Quick Checklist

- [ ] Copy style.css to your project
- [ ] Copy js folder to your project
- [ ] Update asset paths in HTML
- [ ] Customize colors/branding
- [ ] Add your menu items
- [ ] Test responsive design
- [ ] Add your data/content
- [ ] Deploy!

---

**Ready to use in any PHP framework!** The design is framework-agnostic and works with Laravel, CodeIgniter, WordPress, or plain PHP. 🎉
